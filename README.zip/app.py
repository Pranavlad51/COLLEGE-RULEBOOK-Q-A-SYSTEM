import os
import streamlit as st
import numpy as np
from PyPDF2 import PdfReader
from sentence_transformers import SentenceTransformer
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
st.set_page_config(page_title="College Rulebook Q&A", page_icon="📘")
st.title("📘 College Rulebook Q&A")
st.caption("Answers are grounded in the uploaded handbook. This demo handbook is not your own college's official policy.")

@st.cache_resource
def load_model():
    return SentenceTransformer("all-MiniLM-L6-v2")

model = load_model()
api_key = os.getenv("GROQ_API_KEY")
if not api_key:
    st.error("Missing GROQ_API_KEY. Add it to your .env file and restart the app.")
    st.stop()
client = Groq(api_key=api_key)

uploaded_file = st.file_uploader("Upload a text-based college handbook PDF", type=["pdf"])

def extract_pages(pdf):
    reader = PdfReader(pdf)
    pages = []
    for page_no, page in enumerate(reader.pages, start=1):
        txt = page.extract_text() or ""
        if txt.strip():
            pages.append((page_no, txt))
    return pages

def chunk_pages(pages, chunk_words=450, overlap=80):
    chunks=[]
    step=chunk_words-overlap
    for page_no, text in pages:
        words=text.split()
        for start in range(0,len(words),step):
            part=words[start:start+chunk_words]
            if part:
                chunks.append({"page":page_no,"text":" ".join(part)})
    return chunks

def encode_chunks(chunks):
    texts=[c["text"] for c in chunks]
    return model.encode(texts,normalize_embeddings=True,convert_to_numpy=True)

def retrieve(question,chunks,vectors,k=4):
    qv=model.encode([question],normalize_embeddings=True,convert_to_numpy=True)[0]
    scores=np.dot(vectors,qv)
    idx=np.argsort(scores)[::-1][:k]
    # Conservative threshold to avoid passing obviously irrelevant text.
    if len(idx)==0 or float(scores[idx[0]]) < 0.22:
        return "", []
    selected=[chunks[i] for i in idx if float(scores[i]) >= 0.18]
    context="\n\n".join(f"[Page {c['page']}]\n{c['text']}" for c in selected)
    return context,selected

def answer_question(question,context):
    if not context.strip():
        return "Not found in the college handbook.", []
    prompt=f"""You are a College Rulebook Q&A assistant.
Answer the question ONLY using the handbook excerpts below.
Do not use outside knowledge or invent policy.
If the excerpts do not contain the answer, reply exactly:
Not found in the college handbook.
Keep the answer concise and cite the page number(s) in the excerpt as [Page N].

HANDBOOK EXCERPTS:
{context}

STUDENT QUESTION:
{question}

ANSWER:"""
    response=client.chat.completions.create(
        model="openai/gpt-oss-20b",
        messages=[{"role":"user","content":prompt}],
        temperature=0
    )
    return response.choices[0].message.content, []

if uploaded_file:
    file_signature=(uploaded_file.name,uploaded_file.size)
    if st.session_state.get("file_signature") != file_signature:
        with st.spinner("Reading PDF and creating searchable embeddings..."):
            pages=extract_pages(uploaded_file)
            if not pages:
                st.error("No extractable text found. This may be a scanned PDF; try OCR first.")
                st.stop()
            chunks=chunk_pages(pages)
            if not chunks:
                st.error("No text chunks were created.")
                st.stop()
            vectors=encode_chunks(chunks)
            st.session_state.chunks=chunks
            st.session_state.vectors=vectors
            st.session_state.file_signature=file_signature
            st.session_state.messages=[]
        st.success(f"Processed {len(pages)} text pages and {len(st.session_state.chunks)} chunks.")

    if "messages" not in st.session_state:
        st.session_state.messages=[]

    for m in st.session_state.messages:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])

    question=st.chat_input("Ask about attendance, exams, conduct, or college policies...")
    if question:
        st.session_state.messages.append({"role":"user","content":question})
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant"):
            with st.spinner("Searching handbook..."):
                context, selected=retrieve(question,st.session_state.chunks,st.session_state.vectors)
                answer,_=answer_question(question,context)
                if selected and answer != "Not found in the college handbook.":
                    pages_used=sorted(set(c["page"] for c in selected))
                    st.caption("Retrieved handbook pages: "+", ".join(map(str,pages_used)))
                st.markdown(answer)
        st.session_state.messages.append({"role":"assistant","content":answer})
else:
    st.info("Upload the sample PDF or your own college handbook to begin.")
