# College Rulebook Q&A (Problem 32)

A small Retrieval-Augmented Generation (RAG) chatbot that retrieves passages from a college handbook PDF and answers questions grounded in that document.

## Features
- PDF text extraction with PyPDF2
- Chunking with page tracking
- Embeddings using Sentence Transformers (`all-MiniLM-L6-v2`)
- Cosine similarity retrieval using NumPy
- Groq LLM answer generation with a context-only prompt
- Streamlit chat UI and page references

## Requirements
Python 3.10+ recommended. Internet connection required initially to download the embedding model and to call Groq.

## Setup (Windows / VS Code)
1. Install Python from python.org if it is not already installed.
2. Create/open this project folder in VS Code.
3. In terminal, create an environment (optional but recommended):
   `python -m venv .venv`
4. Activate it:
   PowerShell: `.\.venv\Scripts\Activate.ps1`
5. Install dependencies:
   `pip install -r requirements.txt`
6. Create `.env` in this folder and add:
   `GROQ_API_KEY=your_key_here`
7. Obtain a Groq API key from https://console.groq.com/ and keep it private.
8. Run:
   `python -m streamlit run app.py`
9. Upload a text-based handbook PDF in the app.

## Sample handbook
The project can be tested using a public college conduct handbook, for example:
https://sydenham.ac.in/pdf/code%20of%20conduct%20new.pdf
Download the PDF yourself and upload it in the app. Confirm that the PDF's contents and availability are suitable for your submission. This sample is not a substitute for your own college's rules.

## Test questions
1. What is the minimum attendance required?
2. What are the examination rules?
3. Is smoking allowed on campus?
4. What happens if a student is caught cheating?
5. Is carrying an identity card compulsory?
6. What are the disciplinary rules?
7. What happens if college property is damaged?
8. What is the procedure for absence during an examination?
9. What are hostel entry and exit timings?
10. What is the rule for late assignment submission?

Record the actual answers and screenshots from your run in the report. Do not fabricate test results.

## Safety and limitations
- Answers depend on the content and quality of the uploaded PDF and retrieval.
- Scanned PDFs may need OCR before use.
- The similarity threshold is heuristic and should be evaluated.
- This demo does not guarantee perfect refusal of unsupported questions.
- The handbook and API key should not be committed to GitHub unless permitted.
